import pygame
import sys

WINDOW_WIDTH,WINDOW_HEIGHT = 1280,720
